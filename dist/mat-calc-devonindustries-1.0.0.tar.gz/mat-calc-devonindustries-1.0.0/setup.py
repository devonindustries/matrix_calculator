import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="mat-calc-devonindustries", # Replace with your own username
    version="1.0.0",
    author="Joshua Baker",
    author_email="jd.baker01@hotmail.co.nz",
    description="Matrix Calculator",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/devonindustries/matrix_calculator",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7.6',
)