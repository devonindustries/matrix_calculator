# matrix_calculator
A class based matrix calculator project, just for fun.
